Chip's Challenge 1.0.2 — WebAssembly

This is a static browser build. Extract the complete folder and deploy all of
its files together to a web server. Open index.html or chips-native.html over
HTTP or HTTPS; opening either page directly with file:// is not supported.

On Windows, double-click Launch-Chips-Challenge.cmd to start a local server
and open the game in your default browser. Close the minimized server console
window when you are done.

For local testing, run: python3 -m http.server 8000
Then open: http://localhost:8000/

The server must serve .wasm files as application/wasm for streaming startup.
The loader also includes a non-streaming fallback. Click or tap the game once
to enable browser audio. Progress is saved in browser IndexedDB for this site.
Custom .dat level packs are selected through the in-game Level menu.

This WebAssembly package is unsigned. Its ZIP checksum is recorded in
SHA256SUMS.txt next to the archive.

On macOS, double-click Launch-Chips-Challenge.command. Its Terminal window
will open the game and keep the local server running; press Ctrl+C to stop it.
On Linux, run Launch-Chips-Challenge.sh from a terminal, or use your file
manager's Run option. The launcher requires Python 3; Linux also needs xdg-open.

The browser synthesizer loads its included GeneralUser GS sound bank the first
time background music starts; later launches can reuse the browser cache.
