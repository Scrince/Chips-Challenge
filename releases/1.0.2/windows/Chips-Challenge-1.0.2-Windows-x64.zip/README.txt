Chip's Challenge Native 1.0.2 — Windows x64

This is a portable Windows package. Extract the complete folder and run
chips-native.exe. Keep assets, data, and the included DLL files beside it.

The bundled Help menu opens the offline help manual at the selected section.
Third-party license terms are in ThirdPartyNotices.txt.
This package is unsigned; its SHA-256 checksum is recorded beside the ZIP.
